/*
  Copyright @ 1999 ImageMagick Studio LLC, a non-profit organization
  dedicated to making software imaging solutions freely available.
  
  You may not use this file except in compliance with the License.  You may
  obtain a copy of the License at
  
    https://imagemagick.org/script/license.php
  
  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

  MagickCore linked list methods.
*/
#ifndef MAGICKCORE_LINKED_LIST_H
#define MAGICKCORE_LINKED_LIST_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

typedef struct _LinkedListInfo
  LinkedListInfo;

extern MagickExport LinkedListInfo
  *DestroyLinkedList(LinkedListInfo *,void *(*)(void *)),
  *NewLinkedList(const size_t);

extern MagickExport MagickBooleanType
  AppendValueToLinkedList(LinkedListInfo *,const void *),
  InsertValueInLinkedList(LinkedListInfo *,const size_t,const void *),
  InsertValueInSortedLinkedList(LinkedListInfo *,
    int (*)(const void *,const void *),void **,const void *),
  IsLinkedListEmpty(const LinkedListInfo *),
  LinkedListToArray(LinkedListInfo *,void **);

extern MagickExport size_t
  GetNumberOfElementsInLinkedList(const LinkedListInfo *);

extern MagickExport void
  ClearLinkedList(LinkedListInfo *,void *(*)(void *)),
  *GetLastValueInLinkedList(LinkedListInfo *),
  *GetNextValueInLinkedList(LinkedListInfo *),
  *GetValueFromLinkedList(LinkedListInfo *,const size_t),
  *RemoveElementByValueFromLinkedList(LinkedListInfo *,const void *),
  *RemoveElementFromLinkedList(LinkedListInfo *,const size_t),
  *RemoveLastElementFromLinkedList(LinkedListInfo *),
  ResetLinkedListIterator(LinkedListInfo *);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif
